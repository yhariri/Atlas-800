# Copyright 2020 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================
"""train resnet."""
import os
import argparse
import ast
import time

import numpy as np
from mindspore import context, export
from mindspore import Tensor
from mindspore.nn.optim.momentum import Momentum
from mindspore.train.model import Model
from mindspore.context import ParallelMode
from mindspore.train.callback import Callback, CheckpointConfig, LossMonitor, ModelCheckpoint, SummaryCollector, \
    TimeMonitor
from mindspore.nn.loss import SoftmaxCrossEntropyWithLogits
from mindspore.train.loss_scale_manager import FixedLossScaleManager
from mindspore.train.serialization import load_checkpoint, load_param_into_net
from mindspore.communication.management import get_group_size, init
from mindspore.common import set_seed
from mindspore.parallel import set_algo_parameters
import mindspore.nn as nn
import mindspore.common.initializer as weight_init
from src.lr_generator import get_lr, warmup_cosine_annealing_lr
from src.CrossEntropySmooth import CrossEntropySmooth

parser = argparse.ArgumentParser(description='Image classification')
# 适配平台

parser.add_argument('--pretrained_model', type=str, default=None, help='Pretrained checkpoint path')
parser.add_argument('--data_path', type=str, default=None, help='Data path')
parser.add_argument('--output_path', type=str, default=None, help='Output path')

# 用户参数

parser.add_argument('--batch_size', type=int, default=32, help='batch size')
parser.add_argument('--epoch_size', type=int, default=90, help='epoch_size')
parser.add_argument('--lr_init', type=float, default=0.01, help='lr init')

##

parser.add_argument('--net', type=str, default="resnet50", help='Resnet Model, either resnet50 or resnet101')
parser.add_argument('--dataset', type=str, default="cifar10", help='Dataset, either cifar10 or imagenet2012')
parser.add_argument('--run_distribute', type=ast.literal_eval, default=False, help='Run distribute')
parser.add_argument('--device_num', type=int, default=1, help='Device num.')

parser.add_argument('--dataset_path', type=str, default=None, help='Dataset path')
parser.add_argument('--device_target', type=str, default='Ascend', choices=("Ascend", "GPU", "CPU"),
                    help="Device target, support Ascend, GPU and CPU.")
parser.add_argument('--pre_trained', type=str, default=None, help='Pretrained checkpoint path')
parser.add_argument('--parameter_server', type=ast.literal_eval, default=False, help='Run parameter server train')
args_opt = parser.parse_args()

set_seed(1)

if args_opt.net == "resnet50":
    from src.resnet import resnet50 as resnet

    if args_opt.dataset == "cifar10":
        from src.config import config_res50_cifar as config
        from src.dataset import create_dataset_cifar as create_dataset
    else:
        from src.config import config_res50_imgnet as config
        from src.dataset import create_dataset_res50_imgnet as create_dataset
elif args_opt.net == "resnet101":
    from src.resnet import resnet101 as resnet
    from src.config import config_res101_cifar as config
    from src.dataset import create_dataset_res101_imgnet as create_dataset
else:
    from src.resnet import se_resnet50 as resnet
    from src.config import config_seres50_imgnet as config
    from src.dataset import create_dataset_seres50_imgnet as create_dataset


class ProgressMonitor(Callback):
    """monitor loss and cost time."""

    def __init__(self, args):
        super(ProgressMonitor, self).__init__()
        self.me_epoch_start_time = time.time()
        self.me_epoch_start_step_num = -1
        self.args = args

    def epoch_end(self, run_context):
        try:
            device_num = int(get_group_size())
        except:
            device_num = 1
        cb_params = run_context.original_args()
        cur_step_num = cb_params.cur_step_num - 1
        _epoch = cb_params.cur_epoch_num
        time_cost = time.time() - self.me_epoch_start_time
        fps_mean = self.args.batch_size * (cur_step_num - self.me_epoch_start_step_num) * \
                   device_num / time_cost
        per_step_time = 1000 * time_cost / (cur_step_num - self.me_epoch_start_step_num)
        print('epoch[{}],loss: {}, mean_fps: {:.2f}'
              ' imgs/sec, per_step_time: {:.2f} ms'.format(_epoch,
                                                           cb_params.net_outputs,
                                                           fps_mean,
                                                           per_step_time))

        self.me_epoch_start_step_num = cur_step_num
        self.me_epoch_start_time = time.time()


if __name__ == '__main__':
    print(20 * "=")
    print(args_opt)
    print(20 * "=")
    print(20 * "=")
    print(os.listdir(args_opt.data_path))
    print(os.listdir(args_opt.output_path))

    print(20 * "=")
    if not os.path.exists(args_opt.output_path):
        os.mkdir(args_opt.output_path)
    target = args_opt.device_target
    if target == "CPU":
        args_opt.run_distribute = False

    # ckpt_save_dir = config.save_checkpoint_path
    ckpt_save_dir = args_opt.output_path
    config.batch_size = args_opt.batch_size
    config.epoch_size = args_opt.epoch_size
    config.lr_init = args_opt.lr_init
    args_opt.dataset_path = args_opt.data_path
    if args_opt.dataset != "cifar10" and args_opt.dataset != "imagenet":
        args_opt.dataset_path = os.path.join(args_opt.dataset_path, 'annotations')
    # init context
    context.set_context(mode=context.GRAPH_MODE, device_target=target, save_graphs=False)
    if args_opt.parameter_server:
        context.set_ps_context(enable_ps=True)
    if args_opt.run_distribute:
        if target == "Ascend":
            device_id = int(os.getenv('DEVICE_ID'))
            context.set_context(device_id=device_id, enable_auto_mixed_precision=True)
            context.set_auto_parallel_context(device_num=args_opt.device_num, parallel_mode=ParallelMode.DATA_PARALLEL,
                                              gradients_mean=True)
            set_algo_parameters(elementwise_op_strategy_follow=True)
            if args_opt.net == "resnet50" or args_opt.net == "se-resnet50":
                context.set_auto_parallel_context(all_reduce_fusion_config=[85, 160])
            else:
                context.set_auto_parallel_context(all_reduce_fusion_config=[180, 313])
            init()
            # ckpt_save_dir = config.save_checkpoint_path + "ckpt_" + str(get_rank()) + "/"
            # print('ckpt_save_dir',ckpt_save_dir)
        # GPU target
        else:
            init()
            context.set_auto_parallel_context(device_num=get_group_size(), parallel_mode=ParallelMode.DATA_PARALLEL,
                                              gradients_mean=True)
            if args_opt.net == "resnet50":
                context.set_auto_parallel_context(all_reduce_fusion_config=[85, 160])
    ckpt_save_dir = os.path.join(args_opt.output_path)
    print('ckpt_save_dir', ckpt_save_dir)
    # create dataset

    dataset = create_dataset(dataset_path=args_opt.dataset_path, do_train=True, repeat_num=1,
                             batch_size=config.batch_size, target=target, distribute=args_opt.run_distribute)
    step_size = dataset.get_dataset_size()

    # define net
    net = resnet(class_num=config.class_num)
    if args_opt.parameter_server:
        net.set_param_ps()

    # init weight
    args_opt.pre_trained = args_opt.pretrained_model

    if args_opt.pre_trained:
        print(args_opt.pre_trained)
        print(os.listdir(args_opt.pre_trained))
        if args_opt.pre_trained.endswith(".ckpt"):
            param_dict = load_checkpoint(args_opt.pre_trained)
            load_param_into_net(net, param_dict)
        else:
            files = os.listdir(args_opt.pre_trained)
            ckpt_model_list = [file for file in files if file.endswith(".ckpt")]
            pre_trained_model = os.path.join(args_opt.pre_trained, sorted(ckpt_model_list)[-1])
            param_dict = load_checkpoint(pre_trained_model)
            load_param_into_net(net, param_dict)
        print(100 * '=')
        print("restore parameters..", args_opt.pre_trained)
        print(100 * '=')
    else:
        for _, cell in net.cells_and_names():
            if isinstance(cell, nn.Conv2d):
                cell.weight.set_data(weight_init.initializer(weight_init.XavierUniform(),
                                                             cell.weight.shape,
                                                             cell.weight.dtype))
            if isinstance(cell, nn.Dense):
                cell.weight.set_data(weight_init.initializer(weight_init.TruncatedNormal(),
                                                             cell.weight.shape,
                                                             cell.weight.dtype))

    # init lr
    if args_opt.net == "resnet50" or args_opt.net == "se-resnet50":
        lr = get_lr(lr_init=config.lr_init, lr_end=config.lr_end, lr_max=config.lr_max,
                    warmup_epochs=config.warmup_epochs, total_epochs=config.epoch_size, steps_per_epoch=step_size,
                    lr_decay_mode=config.lr_decay_mode)
    else:
        lr = warmup_cosine_annealing_lr(config.lr, step_size, config.warmup_epochs, config.epoch_size,
                                        config.pretrain_epoch_size * step_size)
    lr = Tensor(lr)

    # define opt
    decayed_params = []
    no_decayed_params = []
    for param in net.trainable_params():
        if 'beta' not in param.name and 'gamma' not in param.name and 'bias' not in param.name:
            decayed_params.append(param)
        else:
            no_decayed_params.append(param)

    group_params = [{'params': decayed_params, 'weight_decay': config.weight_decay},
                    {'params': no_decayed_params},
                    {'order_params': net.trainable_params()}]
    opt = Momentum(group_params, lr, config.momentum, loss_scale=config.loss_scale)
    # define loss, model
    if target == "Ascend":
        if args_opt.dataset == "imagenet2012":
            if not config.use_label_smooth:
                config.label_smooth_factor = 0.0
            loss = CrossEntropySmooth(sparse=True, reduction="mean",
                                      smooth_factor=config.label_smooth_factor, num_classes=config.class_num)
        else:
            loss = SoftmaxCrossEntropyWithLogits(sparse=True, reduction='mean')
        loss_scale = FixedLossScaleManager(config.loss_scale, drop_overflow_update=False)
        model = Model(net, loss_fn=loss, optimizer=opt, loss_scale_manager=loss_scale, metrics={'acc'},
                      amp_level="O2", keep_batchnorm_fp32=False)
    else:
        # GPU and CPU target
        if args_opt.dataset == "imagenet2012":
            if not config.use_label_smooth:
                config.label_smooth_factor = 0.0
            loss = CrossEntropySmooth(sparse=True, reduction="mean",
                                      smooth_factor=config.label_smooth_factor, num_classes=config.class_num)
        else:
            loss = SoftmaxCrossEntropyWithLogits(sparse=True, reduction="mean")

        if (args_opt.net == "resnet101" or args_opt.net == "resnet50") and \
                not args_opt.parameter_server and target != "CPU":
            opt = Momentum(filter(lambda x: x.requires_grad, net.get_parameters()), lr, config.momentum,
                           config.weight_decay,
                           config.loss_scale)
            loss_scale = FixedLossScaleManager(config.loss_scale, drop_overflow_update=False)
            # Mixed precision
            model = Model(net, loss_fn=loss, optimizer=opt, loss_scale_manager=loss_scale, metrics={'acc'},
                          amp_level="O2", keep_batchnorm_fp32=False)
        else:
            ## fp32 training
            opt = Momentum(filter(lambda x: x.requires_grad, net.get_parameters()), lr, config.momentum,
                           config.weight_decay)
            model = Model(net, loss_fn=loss, optimizer=opt, metrics={'acc'})

    # define callbacks
    summary_path = os.path.join(args_opt.output_path, "summary")
    if not os.path.exists(summary_path):
        os.mkdir(summary_path)
    summary_collector = SummaryCollector(summary_dir=summary_path, collect_freq=1)

    time_cb = TimeMonitor(data_size=step_size)
    loss_cb = LossMonitor()
    cb = [ProgressMonitor(config), time_cb, loss_cb, summary_collector]

    if config.save_checkpoint and int(os.getenv("RANK_ID", '0')) == 0:
        config_ck = CheckpointConfig(save_checkpoint_steps=config.save_checkpoint_epochs * step_size,
                                     keep_checkpoint_max=config.keep_checkpoint_max)
        ckpt_cb = ModelCheckpoint(prefix="resnet", directory=ckpt_save_dir, config=config_ck)
        cb += [ckpt_cb]

    # train model
    if args_opt.net == "se-resnet50":
        config.epoch_size = config.train_epoch_size
    dataset_sink_mode = (not args_opt.parameter_server) and target != "CPU"
    # dataset_sink_mode = False
    model.train(config.epoch_size - config.pretrain_epoch_size, dataset, callbacks=cb,
                sink_size=dataset.get_dataset_size(), dataset_sink_mode=dataset_sink_mode)
    # exit()
    if int(os.getenv("RANK_ID", '0')) == 0:
        print('susscess training')
        print('start export')
        net = resnet(config.class_num)
        files = os.listdir(os.path.join(args_opt.output_path))
        ckpt_model_list = [file for file in files if file.endswith(".ckpt")]
        ckpt_to_air_model = os.path.join(args_opt.output_path, sorted(ckpt_model_list)[-1])
        param_dict = load_checkpoint(ckpt_to_air_model)
        load_param_into_net(net, param_dict)
        input_arr = Tensor(np.zeros([1, 3, 224, 224], np.float32))
        export(net, input_arr, file_name=os.path.join(args_opt.output_path, "resnet50.air"), file_format="AIR")
        print("============== Susscess Export ==============")
    print(os.listdir(args_opt.output_path))
    # print(os.listdir(os.path.join(args_opt.output_path, "transformer")))
